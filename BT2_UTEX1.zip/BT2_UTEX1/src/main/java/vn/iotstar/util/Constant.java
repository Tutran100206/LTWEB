package vn.iotstar.util;

public class Constant {
    public static final String SESSION_ACCOUNT = "account";
    public static final String SESSION_USERNAME = "username";
    public static final String COOKIE_REMEMBER = "username";

    private Constant() {
    }
}
